#!/usr/bin/env python3
"""
Unit tests for Lambda functions.
"""

import unittest
import json
import base64
import tempfile
import os
from unittest.mock import Mock, patch, MagicMock
import sys
import io

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from lambda.predict import lambda_handler, analyze_with_rekognition, predict_with_custom_model
from lambda.train import lambda_handler as train_lambda_handler

class TestPredictLambda(unittest.TestCase):
    """Test cases for the predict Lambda function."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.sample_image_data = b"fake_image_data"
        self.sample_base64 = base64.b64encode(self.sample_image_data).decode('utf-8')
    
    @patch('lambda.predict.rekognition')
    @patch('lambda.predict.sagemaker_runtime')
    def test_single_prediction_success(self, mock_sagemaker, mock_rekognition):
        """Test successful single image prediction."""
        # Mock Rekognition response
        mock_rekognition.detect_labels.return_value = {
            'Labels': [
                {
                    'Name': 'Person',
                    'Confidence': 95.5,
                    'Instances': [],
                    'Parents': []
                }
            ]
        }
        mock_rekognition.detect_faces.return_value = {'FaceDetails': []}
        mock_rekognition.detect_text.return_value = {'TextDetections': []}
        
        # Mock SageMaker response
        mock_sagemaker.invoke_endpoint.return_value = {
            'Body': io.StringIO('{"predictions": [{"class": "cat", "confidence": 0.8}]}')
        }
        
        # Create test event
        event = {
            'path': '/predict',
            'body': json.dumps({'image': self.sample_base64})
        }
        
        # Call lambda handler
        response = lambda_handler(event, {})
        
        # Assertions
        self.assertEqual(response['statusCode'], 200)
        body = json.loads(response['body'])
        self.assertIn('rekognition', body)
        self.assertIn('custom_model', body)
    
    def test_single_prediction_no_image(self):
        """Test prediction with no image data."""
        event = {
            'path': '/predict',
            'body': json.dumps({})
        }
        
        response = lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 400)
        body = json.loads(response['body'])
        self.assertIn('error', body)
    
    @patch('lambda.predict.rekognition')
    @patch('lambda.predict.sagemaker_runtime')
    def test_batch_prediction_success(self, mock_sagemaker, mock_rekognition):
        """Test successful batch prediction."""
        # Mock responses
        mock_rekognition.detect_labels.return_value = {'Labels': []}
        mock_rekognition.detect_faces.return_value = {'FaceDetails': []}
        mock_rekognition.detect_text.return_value = {'TextDetections': []}
        
        mock_sagemaker.invoke_endpoint.return_value = {
            'Body': io.StringIO('{"predictions": []}')
        }
        
        # Create test event
        event = {
            'path': '/batch-predict',
            'body': json.dumps({
                'images': [self.sample_base64, self.sample_base64]
            })
        }
        
        response = lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 200)
        body = json.loads(response['body'])
        self.assertIn('results', body)
        self.assertEqual(len(body['results']), 2)
    
    def test_batch_prediction_too_many_images(self):
        """Test batch prediction with too many images."""
        event = {
            'path': '/batch-predict',
            'body': json.dumps({
                'images': [self.sample_base64] * 15  # More than 10
            })
        }
        
        response = lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 400)
        body = json.loads(response['body'])
        self.assertIn('error', body)
    
    def test_health_check(self):
        """Test health check endpoint."""
        event = {
            'httpMethod': 'GET',
            'path': '/health'
        }
        
        response = lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 200)
        body = json.loads(response['body'])
        self.assertEqual(body['status'], 'healthy')
    
    def test_invalid_endpoint(self):
        """Test invalid endpoint."""
        event = {
            'path': '/invalid'
        }
        
        response = lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 400)
        body = json.loads(response['body'])
        self.assertIn('error', body)

class TestTrainLambda(unittest.TestCase):
    """Test cases for the train Lambda function."""
    
    @patch('lambda.train.sagemaker')
    def test_start_training_job_success(self, mock_sagemaker):
        """Test successful training job start."""
        # Mock SageMaker response
        mock_sagemaker.create_training_job.return_value = {}
        
        event = {
            'body': json.dumps({
                'training_config': {
                    'epochs': 5,
                    'learning_rate': 0.001
                }
            })
        }
        
        response = train_lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 200)
        body = json.loads(response['body'])
        self.assertIn('training_job_name', body)
        self.assertEqual(body['status'], 'InProgress')
    
    def test_start_training_job_invalid_request(self):
        """Test training job with invalid request."""
        event = {
            'body': 'invalid json'
        }
        
        response = train_lambda_handler(event, {})
        
        self.assertEqual(response['statusCode'], 500)

class TestRekognitionIntegration(unittest.TestCase):
    """Test cases for Rekognition integration."""
    
    @patch('lambda.predict.rekognition')
    def test_analyze_with_rekognition_success(self, mock_rekognition):
        """Test successful Rekognition analysis."""
        # Mock responses
        mock_rekognition.detect_labels.return_value = {
            'Labels': [
                {
                    'Name': 'Person',
                    'Confidence': 95.5,
                    'Instances': [],
                    'Parents': [{'Name': 'People'}]
                }
            ]
        }
        mock_rekognition.detect_faces.return_value = {
            'FaceDetails': [
                {
                    'Confidence': 99.5,
                    'AgeRange': {'Low': 25, 'High': 35},
                    'Gender': {'Value': 'Male', 'Confidence': 98.0},
                    'Emotions': [{'Type': 'Happy', 'Confidence': 85.0}]
                }
            ]
        }
        mock_rekognition.detect_text.return_value = {
            'TextDetections': [
                {
                    'DetectedText': 'Hello World',
                    'Confidence': 95.0,
                    'Type': 'LINE'
                }
            ]
        }
        
        result = analyze_with_rekognition(b"fake_image_data")
        
        self.assertIn('labels', result)
        self.assertIn('faces', result)
        self.assertIn('text', result)
        self.assertEqual(len(result['labels']), 1)
        self.assertEqual(len(result['faces']), 1)
        self.assertEqual(len(result['text']), 1)
    
    @patch('lambda.predict.rekognition')
    def test_analyze_with_rekognition_error(self, mock_rekognition):
        """Test Rekognition analysis with error."""
        mock_rekognition.detect_labels.side_effect = Exception("Rekognition error")
        
        result = analyze_with_rekognition(b"fake_image_data")
        
        self.assertIn('error', result)

class TestCustomModelIntegration(unittest.TestCase):
    """Test cases for custom model integration."""
    
    @patch('lambda.predict.sagemaker_runtime')
    def test_predict_with_custom_model_success(self, mock_sagemaker):
        """Test successful custom model prediction."""
        mock_sagemaker.invoke_endpoint.return_value = {
            'Body': io.StringIO('{"predictions": [{"class": "cat", "confidence": 0.8}]}')
        }
        
        result = predict_with_custom_model(b"fake_image_data")
        
        self.assertIn('predictions', result)
        self.assertIn('model_version', result)
        self.assertIn('inference_time', result)
    
    @patch('lambda.predict.sagemaker_runtime')
    def test_predict_with_custom_model_error(self, mock_sagemaker):
        """Test custom model prediction with error."""
        mock_sagemaker.invoke_endpoint.side_effect = Exception("SageMaker error")
        
        result = predict_with_custom_model(b"fake_image_data")
        
        self.assertIn('error', result)

if __name__ == '__main__':
    unittest.main()
