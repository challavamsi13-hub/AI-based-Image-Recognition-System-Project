#!/usr/bin/env python3
"""
Example usage of the AI Image Recognition System API

This script demonstrates how to use the API for image prediction,
batch processing, and model training.
"""

import requests
import base64
import json
import time
import os
from pathlib import Path
from typing import List, Dict, Any

class AIImageRecognitionClient:
    """Client for the AI Image Recognition System API."""
    
    def __init__(self, base_url: str):
        """
        Initialize the client.
        
        Args:
            base_url: Base URL of the API Gateway
        """
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json'
        })
    
    def health_check(self) -> Dict[str, Any]:
        """Check API health."""
        try:
            response = self.session.get(f"{self.base_url}/health")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Health check failed: {e}")
            return {}
    
    def predict_single_image(self, image_path: str) -> Dict[str, Any]:
        """
        Predict on a single image.
        
        Args:
            image_path: Path to the image file
            
        Returns:
            Prediction results
        """
        try:
            # Read and encode image
            with open(image_path, 'rb') as f:
                image_data = base64.b64encode(f.read()).decode('utf-8')
            
            # Make prediction request
            response = self.session.post(
                f"{self.base_url}/predict",
                json={'image': image_data}
            )
            response.raise_for_status()
            
            return response.json()
            
        except FileNotFoundError:
            print(f"Image file not found: {image_path}")
            return {}
        except requests.exceptions.RequestException as e:
            print(f"Prediction request failed: {e}")
            return {}
    
    def predict_batch_images(self, image_paths: List[str]) -> Dict[str, Any]:
        """
        Predict on multiple images.
        
        Args:
            image_paths: List of image file paths
            
        Returns:
            Batch prediction results
        """
        try:
            # Read and encode images
            images = []
            for image_path in image_paths:
                with open(image_path, 'rb') as f:
                    image_data = base64.b64encode(f.read()).decode('utf-8')
                    images.append(image_data)
            
            # Make batch prediction request
            response = self.session.post(
                f"{self.base_url}/batch-predict",
                json={'images': images}
            )
            response.raise_for_status()
            
            return response.json()
            
        except FileNotFoundError as e:
            print(f"Image file not found: {e}")
            return {}
        except requests.exceptions.RequestException as e:
            print(f"Batch prediction request failed: {e}")
            return {}
    
    def start_training(self, training_config: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Start a training job.
        
        Args:
            training_config: Training configuration
            
        Returns:
            Training job information
        """
        try:
            # Default training configuration
            if training_config is None:
                training_config = {
                    'epochs': 10,
                    'learning_rate': 0.001,
                    'batch_size': 32,
                    'model_name': 'resnet50',
                    'instance_type': 'ml.p3.2xlarge'
                }
            
            # Start training job
            response = self.session.post(
                f"{self.base_url}/train",
                json={'training_config': training_config}
            )
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"Training request failed: {e}")
            return {}

def main():
    """Main example function."""
    
    # Configuration
    API_BASE_URL = "https://your-api-gateway-url/prod"  # Replace with your API URL
    
    # Initialize client
    client = AIImageRecognitionClient(API_BASE_URL)
    
    print("AI Image Recognition System - Example Usage")
    print("=" * 50)
    
    # 1. Health Check
    print("\n1. Checking API health...")
    health = client.health_check()
    if health:
        print(f"✅ API Status: {health.get('status', 'unknown')}")
        print(f"   Service: {health.get('service', 'unknown')}")
        print(f"   Version: {health.get('version', 'unknown')}")
    else:
        print("❌ Health check failed")
        return
    
    # 2. Single Image Prediction
    print("\n2. Single image prediction...")
    
    # Example image paths (replace with your actual image paths)
    sample_images = [
        "sample_images/cat.jpg",
        "sample_images/dog.jpg",
        "sample_images/person.jpg"
    ]
    
    for image_path in sample_images:
        if os.path.exists(image_path):
            print(f"\n   Predicting: {image_path}")
            result = client.predict_single_image(image_path)
            
            if result:
                # Display Rekognition results
                rekognition = result.get('rekognition', {})
                if rekognition.get('labels'):
                    print(f"   Rekognition Labels:")
                    for label in rekognition['labels'][:3]:  # Top 3 labels
                        print(f"     - {label['name']}: {label['confidence']:.1f}%")
                
                # Display custom model results
                custom_model = result.get('custom_model', {})
                if custom_model.get('predictions'):
                    print(f"   Custom Model Predictions:")
                    for pred in custom_model['predictions'][:3]:  # Top 3 predictions
                        print(f"     - {pred['class_name']}: {pred['confidence']:.3f}")
            else:
                print("   ❌ Prediction failed")
        else:
            print(f"   ⚠️  Image not found: {image_path}")
    
    # 3. Batch Prediction
    print("\n3. Batch image prediction...")
    
    # Find all available images
    available_images = [img for img in sample_images if os.path.exists(img)]
    
    if len(available_images) >= 2:
        print(f"   Processing {len(available_images)} images...")
        batch_result = client.predict_batch_images(available_images)
        
        if batch_result and 'results' in batch_result:
            print(f"   ✅ Batch prediction completed")
            print(f"   Results for {len(batch_result['results'])} images:")
            
            for i, result in enumerate(batch_result['results']):
                if 'error' in result:
                    print(f"     Image {i}: ❌ {result['error']}")
                else:
                    custom_model = result.get('custom_model', {})
                    if custom_model.get('predictions'):
                        top_pred = custom_model['predictions'][0]
                        print(f"     Image {i}: {top_pred['class_name']} ({top_pred['confidence']:.3f})")
        else:
            print("   ❌ Batch prediction failed")
    else:
        print("   ⚠️  Not enough images for batch prediction")
    
    # 4. Model Training
    print("\n4. Starting model training...")
    
    training_config = {
        'epochs': 5,  # Reduced for demo
        'learning_rate': 0.001,
        'batch_size': 16,
        'model_name': 'resnet18',  # Smaller model for demo
        'instance_type': 'ml.p3.2xlarge'
    }
    
    training_result = client.start_training(training_config)
    
    if training_result:
        print(f"   ✅ Training job started")
        print(f"   Job Name: {training_result.get('training_job_name', 'unknown')}")
        print(f"   Status: {training_result.get('status', 'unknown')}")
        print(f"   Timestamp: {training_result.get('timestamp', 'unknown')}")
    else:
        print("   ❌ Training job failed to start")
    
    print("\n" + "=" * 50)
    print("Example completed!")
    print("\nNext steps:")
    print("1. Monitor training job progress in AWS SageMaker console")
    print("2. Deploy trained model to SageMaker endpoint")
    print("3. Test predictions with your own images")
    print("4. Monitor API usage in CloudWatch")

def create_sample_images():
    """Create sample images for testing (if they don't exist)."""
    sample_dir = Path("sample_images")
    sample_dir.mkdir(exist_ok=True)
    
    # Create a simple test image (1x1 pixel PNG)
    test_image_data = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x07tIME\x07\xe5\x0c\x1d\x0e\x1c\x0c\xc8\xc8\xc8\x00\x00\x00\x0cIDATx\x9cc```\x00\x00\x00\x04\x00\x01\xf5\xc7\xdd\x8c\x00\x00\x00\x00IEND\xaeB`\x82'
    
    sample_images = [
        "sample_images/cat.jpg",
        "sample_images/dog.jpg", 
        "sample_images/person.jpg"
    ]
    
    for image_path in sample_images:
        if not os.path.exists(image_path):
            # Create a copy of the test image with different names
            with open(image_path, 'wb') as f:
                f.write(test_image_data)
            print(f"Created sample image: {image_path}")

if __name__ == '__main__':
    # Create sample images if they don't exist
    create_sample_images()
    
    # Run the example
    main()
