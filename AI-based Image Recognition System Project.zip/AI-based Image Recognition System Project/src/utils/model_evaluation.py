#!/usr/bin/env python3
"""
Model Evaluation Utilities for Image Recognition System

This module provides utilities for evaluating trained models, including
metrics calculation, confusion matrix generation, and performance analysis.
"""

import os
import json
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_curve, auc
)
from sklearn.preprocessing import label_binarize
from typing import Dict, List, Tuple, Optional, Any
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from PIL import Image
import io
import base64

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ModelEvaluator:
    """Class for evaluating trained models."""
    
    def __init__(self, model_path: str, class_names: List[str], device: str = 'cpu'):
        """
        Initialize the model evaluator.
        
        Args:
            model_path: Path to the trained model
            class_names: List of class names
            device: Device to run evaluation on
        """
        self.model_path = model_path
        self.class_names = class_names
        self.device = torch.device(device)
        self.model = None
        self.transform = None
        
        self._load_model()
        self._setup_transforms()
    
    def _load_model(self):
        """Load the trained model."""
        try:
            # Load model info
            model_info_path = os.path.join(os.path.dirname(self.model_path), 'model_info.json')
            if os.path.exists(model_info_path):
                with open(model_info_path, 'r') as f:
                    self.model_info = json.load(f)
            else:
                self.model_info = {
                    'model_name': 'resnet50',
                    'num_classes': len(self.class_names),
                    'input_size': 224
                }
            
            # Import model class
            from src.sagemaker.training_script import ImageClassifier
            
            # Create model
            self.model = ImageClassifier(
                num_classes=len(self.class_names),
                model_name=self.model_info['model_name'],
                pretrained=False
            )
            
            # Load weights
            self.model.load_state_dict(torch.load(self.model_path, map_location=self.device))
            self.model.to(self.device)
            self.model.eval()
            
            logger.info(f"Model loaded from {self.model_path}")
            
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise
    
    def _setup_transforms(self):
        """Setup data transforms for evaluation."""
        self.transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    
    def evaluate_dataset(self, data_dir: str, batch_size: int = 32) -> Dict[str, Any]:
        """
        Evaluate model on a dataset.
        
        Args:
            data_dir: Directory containing test data
            batch_size: Batch size for evaluation
            
        Returns:
            Dictionary containing evaluation results
        """
        try:
            # Load dataset
            dataset = datasets.ImageFolder(data_dir, transform=self.transform)
            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
            
            # Get predictions
            all_predictions = []
            all_labels = []
            all_probabilities = []
            
            with torch.no_grad():
                for images, labels in dataloader:
                    images = images.to(self.device)
                    outputs = self.model(images)
                    probabilities = torch.softmax(outputs, dim=1)
                    predictions = torch.argmax(probabilities, dim=1)
                    
                    all_predictions.extend(predictions.cpu().numpy())
                    all_labels.extend(labels.cpu().numpy())
                    all_probabilities.extend(probabilities.cpu().numpy())
            
            # Calculate metrics
            metrics = self._calculate_metrics(all_labels, all_predictions, all_probabilities)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error evaluating dataset: {str(e)}")
            raise
    
    def _calculate_metrics(self, true_labels: List[int], predictions: List[int], 
                          probabilities: List[List[float]]) -> Dict[str, Any]:
        """
        Calculate evaluation metrics.
        
        Args:
            true_labels: True labels
            predictions: Predicted labels
            probabilities: Prediction probabilities
            
        Returns:
            Dictionary containing calculated metrics
        """
        try:
            # Convert to numpy arrays
            true_labels = np.array(true_labels)
            predictions = np.array(predictions)
            probabilities = np.array(probabilities)
            
            # Basic metrics
            accuracy = accuracy_score(true_labels, predictions)
            precision = precision_score(true_labels, predictions, average='weighted')
            recall = recall_score(true_labels, predictions, average='weighted')
            f1 = f1_score(true_labels, predictions, average='weighted')
            
            # Per-class metrics
            precision_per_class = precision_score(true_labels, predictions, average=None)
            recall_per_class = recall_score(true_labels, predictions, average=None)
            f1_per_class = f1_score(true_labels, predictions, average=None)
            
            # Confusion matrix
            cm = confusion_matrix(true_labels, predictions)
            
            # ROC curve and AUC (for binary classification or one-vs-rest)
            roc_data = {}
            if len(self.class_names) == 2:
                # Binary classification
                fpr, tpr, _ = roc_curve(true_labels, probabilities[:, 1])
                roc_auc = auc(fpr, tpr)
                roc_data = {
                    'fpr': fpr.tolist(),
                    'tpr': tpr.tolist(),
                    'auc': roc_auc
                }
            else:
                # Multi-class classification
                true_labels_bin = label_binarize(true_labels, classes=range(len(self.class_names)))
                roc_aucs = []
                fprs = []
                tprs = []
                
                for i in range(len(self.class_names)):
                    fpr, tpr, _ = roc_curve(true_labels_bin[:, i], probabilities[:, i])
                    roc_auc = auc(fpr, tpr)
                    roc_aucs.append(roc_auc)
                    fprs.append(fpr.tolist())
                    tprs.append(tpr.tolist())
                
                roc_data = {
                    'fprs': fprs,
                    'tprs': tprs,
                    'aucs': roc_aucs,
                    'mean_auc': np.mean(roc_aucs)
                }
            
            # Classification report
            report = classification_report(true_labels, predictions, 
                                         target_names=self.class_names, output_dict=True)
            
            # Compile results
            results = {
                'overall_metrics': {
                    'accuracy': accuracy,
                    'precision': precision,
                    'recall': recall,
                    'f1_score': f1
                },
                'per_class_metrics': {
                    'precision': precision_per_class.tolist(),
                    'recall': recall_per_class.tolist(),
                    'f1_score': f1_per_class.tolist()
                },
                'confusion_matrix': cm.tolist(),
                'roc_data': roc_data,
                'classification_report': report,
                'class_names': self.class_names
            }
            
            return results
            
        except Exception as e:
            logger.error(f"Error calculating metrics: {str(e)}")
            raise
    
    def predict_single_image(self, image_path: str) -> Dict[str, Any]:
        """
        Predict on a single image.
        
        Args:
            image_path: Path to the image
            
        Returns:
            Dictionary containing prediction results
        """
        try:
            # Load and preprocess image
            image = Image.open(image_path)
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            image_tensor = self.transform(image).unsqueeze(0).to(self.device)
            
            # Make prediction
            with torch.no_grad():
                outputs = self.model(image_tensor)
                probabilities = torch.softmax(outputs, dim=1)
                predicted_class = torch.argmax(probabilities, dim=1).item()
                confidence = probabilities[0][predicted_class].item()
            
            # Get top 5 predictions
            top5_probs, top5_indices = torch.topk(probabilities, 5)
            
            predictions = []
            for i in range(5):
                predictions.append({
                    'class_name': self.class_names[top5_indices[0][i].item()],
                    'class_id': top5_indices[0][i].item(),
                    'confidence': top5_probs[0][i].item()
                })
            
            return {
                'predictions': predictions,
                'top_prediction': {
                    'class_name': self.class_names[predicted_class],
                    'class_id': predicted_class,
                    'confidence': confidence
                }
            }
            
        except Exception as e:
            logger.error(f"Error predicting single image: {str(e)}")
            raise
    
    def predict_batch_images(self, image_paths: List[str]) -> List[Dict[str, Any]]:
        """
        Predict on a batch of images.
        
        Args:
            image_paths: List of image paths
            
        Returns:
            List of prediction results
        """
        results = []
        for image_path in image_paths:
            try:
                result = self.predict_single_image(image_path)
                results.append(result)
            except Exception as e:
                logger.error(f"Error predicting {image_path}: {str(e)}")
                results.append({'error': str(e)})
        
        return results

class EvaluationVisualizer:
    """Class for creating evaluation visualizations."""
    
    def __init__(self, output_dir: str):
        """
        Initialize the visualizer.
        
        Args:
            output_dir: Directory to save visualizations
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def plot_confusion_matrix(self, confusion_matrix: np.ndarray, class_names: List[str], 
                             save_path: Optional[str] = None) -> str:
        """
        Plot confusion matrix.
        
        Args:
            confusion_matrix: Confusion matrix array
            class_names: List of class names
            save_path: Path to save the plot (optional)
            
        Returns:
            Path to saved plot
        """
        try:
            plt.figure(figsize=(10, 8))
            sns.heatmap(confusion_matrix, annot=True, fmt='d', cmap='Blues',
                       xticklabels=class_names, yticklabels=class_names)
            plt.title('Confusion Matrix')
            plt.xlabel('Predicted')
            plt.ylabel('True')
            plt.xticks(rotation=45)
            plt.yticks(rotation=0)
            plt.tight_layout()
            
            if save_path is None:
                save_path = os.path.join(self.output_dir, 'confusion_matrix.png')
            
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return save_path
            
        except Exception as e:
            logger.error(f"Error plotting confusion matrix: {str(e)}")
            raise
    
    def plot_roc_curves(self, roc_data: Dict[str, Any], class_names: List[str],
                       save_path: Optional[str] = None) -> str:
        """
        Plot ROC curves.
        
        Args:
            roc_data: ROC curve data
            class_names: List of class names
            save_path: Path to save the plot (optional)
            
        Returns:
            Path to saved plot
        """
        try:
            plt.figure(figsize=(10, 8))
            
            if 'auc' in roc_data:
                # Binary classification
                plt.plot(roc_data['fpr'], roc_data['tpr'], 
                        label=f'ROC curve (AUC = {roc_data["auc"]:.3f})')
            else:
                # Multi-class classification
                for i, class_name in enumerate(class_names):
                    plt.plot(roc_data['fprs'][i], roc_data['tprs'][i],
                            label=f'{class_name} (AUC = {roc_data["aucs"][i]:.3f})')
            
            plt.plot([0, 1], [0, 1], 'k--', label='Random')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title('ROC Curves')
            plt.legend()
            plt.grid(True)
            
            if save_path is None:
                save_path = os.path.join(self.output_dir, 'roc_curves.png')
            
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return save_path
            
        except Exception as e:
            logger.error(f"Error plotting ROC curves: {str(e)}")
            raise
    
    def plot_metrics_comparison(self, metrics: Dict[str, Any], save_path: Optional[str] = None) -> str:
        """
        Plot metrics comparison.
        
        Args:
            metrics: Evaluation metrics
            save_path: Path to save the plot (optional)
            
        Returns:
            Path to saved plot
        """
        try:
            # Extract per-class metrics
            precision = metrics['per_class_metrics']['precision']
            recall = metrics['per_class_metrics']['recall']
            f1_scores = metrics['per_class_metrics']['f1_score']
            class_names = metrics['class_names']
            
            # Create bar plot
            fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(15, 5))
            
            x = np.arange(len(class_names))
            width = 0.35
            
            # Precision
            ax1.bar(x, precision, width, label='Precision', color='skyblue')
            ax1.set_xlabel('Classes')
            ax1.set_ylabel('Precision')
            ax1.set_title('Precision by Class')
            ax1.set_xticks(x)
            ax1.set_xticklabels(class_names, rotation=45)
            ax1.legend()
            
            # Recall
            ax2.bar(x, recall, width, label='Recall', color='lightgreen')
            ax2.set_xlabel('Classes')
            ax2.set_ylabel('Recall')
            ax2.set_title('Recall by Class')
            ax2.set_xticks(x)
            ax2.set_xticklabels(class_names, rotation=45)
            ax2.legend()
            
            # F1 Score
            ax3.bar(x, f1_scores, width, label='F1 Score', color='salmon')
            ax3.set_xlabel('Classes')
            ax3.set_ylabel('F1 Score')
            ax3.set_title('F1 Score by Class')
            ax3.set_xticks(x)
            ax3.set_xticklabels(class_names, rotation=45)
            ax3.legend()
            
            plt.tight_layout()
            
            if save_path is None:
                save_path = os.path.join(self.output_dir, 'metrics_comparison.png')
            
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return save_path
            
        except Exception as e:
            logger.error(f"Error plotting metrics comparison: {str(e)}")
            raise

def save_evaluation_results(results: Dict[str, Any], output_path: str):
    """
    Save evaluation results to JSON file.
    
    Args:
        results: Evaluation results
        output_path: Path to save the results
    """
    try:
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"Evaluation results saved to {output_path}")
        
    except Exception as e:
        logger.error(f"Error saving evaluation results: {str(e)}")
        raise

def main():
    """Main function for model evaluation."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Evaluate trained model')
    parser.add_argument('--model-path', type=str, required=True, help='Path to trained model')
    parser.add_argument('--test-dir', type=str, required=True, help='Test dataset directory')
    parser.add_argument('--class-names', type=str, help='Path to class names JSON file')
    parser.add_argument('--output-dir', type=str, default='evaluation_results', help='Output directory')
    parser.add_argument('--batch-size', type=int, default=32, help='Batch size for evaluation')
    parser.add_argument('--device', type=str, default='cpu', help='Device to use')
    
    args = parser.parse_args()
    
    # Load class names
    if args.class_names:
        with open(args.class_names, 'r') as f:
            class_names = json.load(f)
    else:
        # Extract from test directory
        class_names = [d for d in os.listdir(args.test_dir) 
                      if os.path.isdir(os.path.join(args.test_dir, d))]
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Initialize evaluator
    evaluator = ModelEvaluator(args.model_path, class_names, args.device)
    
    # Evaluate model
    logger.info("Starting model evaluation...")
    results = evaluator.evaluate_dataset(args.test_dir, args.batch_size)
    
    # Save results
    results_path = os.path.join(args.output_dir, 'evaluation_results.json')
    save_evaluation_results(results, results_path)
    
    # Create visualizations
    visualizer = EvaluationVisualizer(args.output_dir)
    
    # Plot confusion matrix
    cm_path = visualizer.plot_confusion_matrix(
        np.array(results['confusion_matrix']), 
        results['class_names']
    )
    
    # Plot ROC curves
    roc_path = visualizer.plot_roc_curves(
        results['roc_data'], 
        results['class_names']
    )
    
    # Plot metrics comparison
    metrics_path = visualizer.plot_metrics_comparison(results)
    
    # Print summary
    print("\n=== Evaluation Summary ===")
    print(f"Overall Accuracy: {results['overall_metrics']['accuracy']:.4f}")
    print(f"Overall Precision: {results['overall_metrics']['precision']:.4f}")
    print(f"Overall Recall: {results['overall_metrics']['recall']:.4f}")
    print(f"Overall F1 Score: {results['overall_metrics']['f1_score']:.4f}")
    
    if 'mean_auc' in results['roc_data']:
        print(f"Mean AUC: {results['roc_data']['mean_auc']:.4f}")
    
    print(f"\nResults saved to: {args.output_dir}")
    print(f"Confusion matrix: {cm_path}")
    print(f"ROC curves: {roc_path}")
    print(f"Metrics comparison: {metrics_path}")

if __name__ == '__main__':
    main()
