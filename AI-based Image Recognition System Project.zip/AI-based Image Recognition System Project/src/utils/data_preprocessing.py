#!/usr/bin/env python3
"""
Data Preprocessing Utilities for Image Recognition System

This module provides utilities for preprocessing image data, including
augmentation, dataset preparation, and S3 operations.
"""

import os
import json
import logging
import boto3
import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import albumentations as A
from sklearn.model_selection import train_test_split
import shutil

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ImagePreprocessor:
    """Class for preprocessing images for training."""
    
    def __init__(self, input_size: int = 224, augment: bool = True):
        """
        Initialize the preprocessor.
        
        Args:
            input_size: Target size for images
            augment: Whether to apply augmentation
        """
        self.input_size = input_size
        self.augment = augment
        
        # Define augmentation pipeline
        if self.augment:
            self.augmentation = A.Compose([
                A.RandomRotate90(p=0.5),
                A.Flip(p=0.5),
                A.Transpose(p=0.5),
                A.OneOf([
                    A.IAAAdditiveGaussianNoise(),
                    A.GaussNoise(),
                ], p=0.2),
                A.OneOf([
                    A.MotionBlur(p=0.2),
                    A.MedianBlur(blur_limit=3, p=0.1),
                    A.Blur(blur_limit=3, p=0.1),
                ], p=0.2),
                A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.2, rotate_limit=45, p=0.2),
                A.OneOf([
                    A.OpticalDistortion(p=0.3),
                    A.GridDistortion(p=0.1),
                    A.IAAPiecewiseAffine(p=0.3),
                ], p=0.2),
                A.OneOf([
                    A.CLAHE(clip_limit=2),
                    A.IAASharpen(),
                    A.IAAEmboss(),
                    A.RandomBrightnessContrast(),
                ], p=0.3),
                A.HueSaturationValue(p=0.3),
            ])
    
    def preprocess_image(self, image_path: str, save_path: Optional[str] = None) -> np.ndarray:
        """
        Preprocess a single image.
        
        Args:
            image_path: Path to the input image
            save_path: Path to save the processed image (optional)
            
        Returns:
            Preprocessed image as numpy array
        """
        try:
            # Load image
            image = Image.open(image_path)
            
            # Convert to RGB if necessary
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Convert to numpy array
            image_array = np.array(image)
            
            # Apply augmentation if enabled
            if self.augment:
                augmented = self.augmentation(image=image_array)
                image_array = augmented['image']
            
            # Resize image
            image = Image.fromarray(image_array)
            image = image.resize((self.input_size, self.input_size))
            
            # Save if path provided
            if save_path:
                image.save(save_path)
            
            return np.array(image)
            
        except Exception as e:
            logger.error(f"Error preprocessing image {image_path}: {str(e)}")
            raise
    
    def preprocess_dataset(self, input_dir: str, output_dir: str, 
                          class_names: Optional[List[str]] = None) -> Dict[str, int]:
        """
        Preprocess an entire dataset.
        
        Args:
            input_dir: Input directory containing class folders
            output_dir: Output directory for processed images
            class_names: List of class names (optional)
            
        Returns:
            Dictionary mapping class names to counts
        """
        try:
            # Create output directory
            os.makedirs(output_dir, exist_ok=True)
            
            # Get class names if not provided
            if class_names is None:
                class_names = [d for d in os.listdir(input_dir) 
                              if os.path.isdir(os.path.join(input_dir, d))]
            
            class_counts = {}
            
            for class_name in class_names:
                class_input_dir = os.path.join(input_dir, class_name)
                class_output_dir = os.path.join(output_dir, class_name)
                
                if not os.path.exists(class_input_dir):
                    logger.warning(f"Class directory {class_input_dir} not found")
                    continue
                
                # Create output directory for this class
                os.makedirs(class_output_dir, exist_ok=True)
                
                # Process images in this class
                image_files = [f for f in os.listdir(class_input_dir) 
                              if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
                
                count = 0
                for image_file in image_files:
                    input_path = os.path.join(class_input_dir, image_file)
                    output_path = os.path.join(class_output_dir, image_file)
                    
                    try:
                        self.preprocess_image(input_path, output_path)
                        count += 1
                    except Exception as e:
                        logger.error(f"Error processing {input_path}: {str(e)}")
                
                class_counts[class_name] = count
                logger.info(f"Processed {count} images for class {class_name}")
            
            return class_counts
            
        except Exception as e:
            logger.error(f"Error preprocessing dataset: {str(e)}")
            raise

class S3DataManager:
    """Class for managing data in S3."""
    
    def __init__(self, bucket_name: str, region: str = 'us-east-1'):
        """
        Initialize the S3 data manager.
        
        Args:
            bucket_name: S3 bucket name
            region: AWS region
        """
        self.bucket_name = bucket_name
        self.s3_client = boto3.client('s3', region_name=region)
        self.s3_resource = boto3.resource('s3', region_name=region)
    
    def upload_file(self, local_path: str, s3_key: str) -> bool:
        """
        Upload a file to S3.
        
        Args:
            local_path: Local file path
            s3_key: S3 object key
            
        Returns:
            True if successful, False otherwise
        """
        try:
            self.s3_client.upload_file(local_path, self.bucket_name, s3_key)
            logger.info(f"Uploaded {local_path} to s3://{self.bucket_name}/{s3_key}")
            return True
        except Exception as e:
            logger.error(f"Error uploading {local_path}: {str(e)}")
            return False
    
    def upload_directory(self, local_dir: str, s3_prefix: str) -> Dict[str, bool]:
        """
        Upload a directory to S3.
        
        Args:
            local_dir: Local directory path
            s3_prefix: S3 prefix for the directory
            
        Returns:
            Dictionary mapping file paths to upload success status
        """
        results = {}
        
        for root, dirs, files in os.walk(local_dir):
            for file in files:
                local_path = os.path.join(root, file)
                relative_path = os.path.relpath(local_path, local_dir)
                s3_key = os.path.join(s3_prefix, relative_path).replace('\\', '/')
                
                success = self.upload_file(local_path, s3_key)
                results[local_path] = success
        
        return results
    
    def download_file(self, s3_key: str, local_path: str) -> bool:
        """
        Download a file from S3.
        
        Args:
            s3_key: S3 object key
            local_path: Local file path
            
        Returns:
            True if successful, False otherwise
        """
        try:
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            self.s3_client.download_file(self.bucket_name, s3_key, local_path)
            logger.info(f"Downloaded s3://{self.bucket_name}/{s3_key} to {local_path}")
            return True
        except Exception as e:
            logger.error(f"Error downloading {s3_key}: {str(e)}")
            return False
    
    def list_objects(self, prefix: str = '') -> List[str]:
        """
        List objects in S3 bucket with given prefix.
        
        Args:
            prefix: S3 prefix to filter objects
            
        Returns:
            List of object keys
        """
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix
            )
            
            if 'Contents' in response:
                return [obj['Key'] for obj in response['Contents']]
            else:
                return []
                
        except Exception as e:
            logger.error(f"Error listing objects: {str(e)}")
            return []

class DatasetSplitter:
    """Class for splitting datasets into train/validation/test sets."""
    
    def __init__(self, train_ratio: float = 0.7, val_ratio: float = 0.2, test_ratio: float = 0.1):
        """
        Initialize the dataset splitter.
        
        Args:
            train_ratio: Ratio for training set
            val_ratio: Ratio for validation set
            test_ratio: Ratio for test set
        """
        assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "Ratios must sum to 1.0"
        self.train_ratio = train_ratio
        self.val_ratio = val_ratio
        self.test_ratio = test_ratio
    
    def split_dataset(self, input_dir: str, output_dir: str) -> Dict[str, Dict[str, int]]:
        """
        Split dataset into train/validation/test sets.
        
        Args:
            input_dir: Input directory containing class folders
            output_dir: Output directory for split datasets
            
        Returns:
            Dictionary containing split information
        """
        try:
            # Create output directories
            train_dir = os.path.join(output_dir, 'train')
            val_dir = os.path.join(output_dir, 'val')
            test_dir = os.path.join(output_dir, 'test')
            
            for dir_path in [train_dir, val_dir, test_dir]:
                os.makedirs(dir_path, exist_ok=True)
            
            split_info = {'train': {}, 'val': {}, 'test': {}}
            
            # Get class names
            class_names = [d for d in os.listdir(input_dir) 
                          if os.path.isdir(os.path.join(input_dir, d))]
            
            for class_name in class_names:
                class_input_dir = os.path.join(input_dir, class_name)
                
                # Get all images in this class
                image_files = [f for f in os.listdir(class_input_dir) 
                              if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
                
                # Split the files
                train_files, temp_files = train_test_split(
                    image_files, 
                    test_size=(1 - self.train_ratio),
                    random_state=42
                )
                
                val_files, test_files = train_test_split(
                    temp_files,
                    test_size=self.test_ratio / (self.val_ratio + self.test_ratio),
                    random_state=42
                )
                
                # Copy files to respective directories
                for split_name, files, split_dir in [
                    ('train', train_files, train_dir),
                    ('val', val_files, val_dir),
                    ('test', test_files, test_dir)
                ]:
                    class_split_dir = os.path.join(split_dir, class_name)
                    os.makedirs(class_split_dir, exist_ok=True)
                    
                    for file in files:
                        src_path = os.path.join(class_input_dir, file)
                        dst_path = os.path.join(class_split_dir, file)
                        shutil.copy2(src_path, dst_path)
                    
                    split_info[split_name][class_name] = len(files)
            
            return split_info
            
        except Exception as e:
            logger.error(f"Error splitting dataset: {str(e)}")
            raise

def create_class_names_file(dataset_dir: str, output_path: str):
    """
    Create a JSON file with class names from dataset directory.
    
    Args:
        dataset_dir: Dataset directory containing class folders
        output_path: Path to save the class names file
    """
    try:
        class_names = [d for d in os.listdir(dataset_dir) 
                      if os.path.isdir(os.path.join(dataset_dir, d))]
        
        with open(output_path, 'w') as f:
            json.dump(class_names, f, indent=2)
        
        logger.info(f"Created class names file: {output_path}")
        
    except Exception as e:
        logger.error(f"Error creating class names file: {str(e)}")
        raise

def main():
    """Main function for data preprocessing."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Preprocess image dataset')
    parser.add_argument('--input-dir', type=str, required=True, help='Input directory')
    parser.add_argument('--output-dir', type=str, required=True, help='Output directory')
    parser.add_argument('--s3-bucket', type=str, help='S3 bucket for upload')
    parser.add_argument('--s3-prefix', type=str, help='S3 prefix for upload')
    parser.add_argument('--split', action='store_true', help='Split dataset')
    parser.add_argument('--augment', action='store_true', help='Apply augmentation')
    parser.add_argument('--input-size', type=int, default=224, help='Input image size')
    
    args = parser.parse_args()
    
    # Initialize preprocessor
    preprocessor = ImagePreprocessor(input_size=args.input_size, augment=args.augment)
    
    # Preprocess dataset
    logger.info("Starting dataset preprocessing...")
    class_counts = preprocessor.preprocess_dataset(args.input_dir, args.output_dir)
    
    # Split dataset if requested
    if args.split:
        logger.info("Splitting dataset...")
        splitter = DatasetSplitter()
        split_info = splitter.split_dataset(args.output_dir, args.output_dir)
        logger.info(f"Split info: {split_info}")
    
    # Create class names file
    class_names_path = os.path.join(args.output_dir, 'class_names.json')
    create_class_names_file(args.output_dir, class_names_path)
    
    # Upload to S3 if specified
    if args.s3_bucket and args.s3_prefix:
        logger.info("Uploading to S3...")
        s3_manager = S3DataManager(args.s3_bucket)
        results = s3_manager.upload_directory(args.output_dir, args.s3_prefix)
        
        success_count = sum(1 for success in results.values() if success)
        total_count = len(results)
        logger.info(f"Uploaded {success_count}/{total_count} files successfully")
    
    logger.info("Preprocessing completed!")

if __name__ == '__main__':
    main()
