import json
import boto3
import logging
import os
from typing import Dict, Any
from datetime import datetime
import uuid

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
sagemaker = boto3.client('sagemaker', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
s3 = boto3.client('s3', region_name=os.environ.get('AWS_REGION', 'us-east-1'))

# Environment variables
S3_BUCKET = os.environ.get('S3_BUCKET')
MODEL_BUCKET = os.environ.get('MODEL_BUCKET')
SAGEMAKER_ROLE_ARN = os.environ.get('SAGEMAKER_ROLE_ARN')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for triggering SageMaker training jobs.
    
    Args:
        event: API Gateway event containing the request
        context: Lambda context
        
    Returns:
        API Gateway response with training job information
    """
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        
        # Extract training parameters
        training_config = body.get('training_config', {})
        
        # Start training job
        training_job_name = start_training_job(training_config)
        
        return create_response(200, {
            'message': 'Training job started successfully',
            'training_job_name': training_job_name,
            'status': 'InProgress',
            'timestamp': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error in training handler: {str(e)}")
        return create_response(500, {'error': 'Training job failed to start'})

def start_training_job(training_config: Dict[str, Any]) -> str:
    """
    Start a SageMaker training job.
    
    Args:
        training_config: Configuration for the training job
        
    Returns:
        Training job name
    """
    try:
        # Generate unique training job name
        timestamp = datetime.utcnow().strftime('%Y%m%d-%H%M%S')
        training_job_name = f"image-classifier-{timestamp}-{str(uuid.uuid4())[:8]}"
        
        # Default training configuration
        default_config = {
            'algorithm_specification': {
                'TrainingImage': '763104351884.dkr.ecr.us-east-1.amazonaws.com/pytorch-training:1.13.1-gpu-py39-cu117-ubuntu20.04-ec2',
                'TrainingInputMode': 'File'
            },
            'role_arn': SAGEMAKER_ROLE_ARN,
            'input_data_config': [
                {
                    'ChannelName': 'training',
                    'DataSource': {
                        'S3DataSource': {
                            'S3DataType': 'S3Prefix',
                            'S3Uri': f's3://{S3_BUCKET}/training-data/',
                            'S3DataDistributionType': 'FullyReplicated'
                        }
                    },
                    'ContentType': 'application/x-recordio',
                    'CompressionType': 'None'
                },
                {
                    'ChannelName': 'validation',
                    'DataSource': {
                        'S3DataSource': {
                            'S3DataType': 'S3Prefix',
                            'S3Uri': f's3://{S3_BUCKET}/validation-data/',
                            'S3DataDistributionType': 'FullyReplicated'
                        }
                    },
                    'ContentType': 'application/x-recordio',
                    'CompressionType': 'None'
                }
            ],
            'output_data_config': {
                'S3OutputPath': f's3://{MODEL_BUCKET}/models/',
                'KmsKeyId': ''
            },
            'resource_config': {
                'InstanceType': training_config.get('instance_type', 'ml.p3.2xlarge'),
                'InstanceCount': training_config.get('instance_count', 1),
                'VolumeSizeInGB': training_config.get('volume_size_gb', 50)
            },
            'stopping_condition': {
                'MaxRuntimeInSeconds': training_config.get('max_runtime_seconds', 3600),
                'MaxWaitTimeInSeconds': training_config.get('max_wait_time_seconds', 7200)
            },
            'hyper_parameters': {
                'epochs': str(training_config.get('epochs', 10)),
                'learning_rate': str(training_config.get('learning_rate', 0.001)),
                'batch_size': str(training_config.get('batch_size', 32)),
                'num_classes': str(training_config.get('num_classes', 10)),
                'model_name': training_config.get('model_name', 'resnet50')
            },
            'tags': [
                {
                    'Key': 'Project',
                    'Value': 'ai-image-recognition'
                },
                {
                    'Key': 'Environment',
                    'Value': 'dev'
                }
            ]
        }
        
        # Merge with provided configuration
        if training_config:
            default_config.update(training_config)
        
        # Start the training job
        response = sagemaker.create_training_job(
            TrainingJobName=training_job_name,
            **default_config
        )
        
        logger.info(f"Started training job: {training_job_name}")
        return training_job_name
        
    except Exception as e:
        logger.error(f"Error starting training job: {str(e)}")
        raise

def get_training_job_status(training_job_name: str) -> Dict[str, Any]:
    """
    Get the status of a training job.
    
    Args:
        training_job_name: Name of the training job
        
    Returns:
        Dictionary containing training job status and metrics
    """
    try:
        response = sagemaker.describe_training_job(TrainingJobName=training_job_name)
        
        return {
            'training_job_name': training_job_name,
            'status': response['TrainingJobStatus'],
            'creation_time': response['CreationTime'].isoformat(),
            'last_modified_time': response['LastModifiedTime'].isoformat(),
            'training_start_time': response.get('TrainingStartTime', '').isoformat() if response.get('TrainingStartTime') else None,
            'training_end_time': response.get('TrainingEndTime', '').isoformat() if response.get('TrainingEndTime') else None,
            'final_metric_data': response.get('FinalMetricDataList', []),
            'model_artifacts': response.get('ModelArtifacts', {}).get('S3ModelArtifacts', ''),
            'failure_reason': response.get('FailureReason', '')
        }
        
    except Exception as e:
        logger.error(f"Error getting training job status: {str(e)}")
        return {'error': 'Failed to get training job status'}

def list_training_jobs() -> Dict[str, Any]:
    """
    List all training jobs for the project.
    
    Returns:
        Dictionary containing list of training jobs
    """
    try:
        response = sagemaker.list_training_jobs(
            MaxResults=50,
            NameContains='image-classifier'
        )
        
        training_jobs = []
        for job in response['TrainingJobSummaries']:
            training_jobs.append({
                'training_job_name': job['TrainingJobName'],
                'status': job['TrainingJobStatus'],
                'creation_time': job['CreationTime'].isoformat(),
                'last_modified_time': job['LastModifiedTime'].isoformat()
            })
        
        return {'training_jobs': training_jobs}
        
    except Exception as e:
        logger.error(f"Error listing training jobs: {str(e)}")
        return {'error': 'Failed to list training jobs'}

def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create API Gateway response.
    
    Args:
        status_code: HTTP status code
        body: Response body
        
    Returns:
        API Gateway response format
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body, default=str)
    }
