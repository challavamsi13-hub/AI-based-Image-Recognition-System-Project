import json
import base64
import boto3
import logging
import os
from typing import Dict, List, Any
from PIL import Image
import io
import numpy as np

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
rekognition = boto3.client('rekognition', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
s3 = boto3.client('s3', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
sagemaker_runtime = boto3.client('sagemaker-runtime', region_name=os.environ.get('AWS_REGION', 'us-east-1'))

# Environment variables
S3_BUCKET = os.environ.get('S3_BUCKET')
MODEL_BUCKET = os.environ.get('MODEL_BUCKET')
SAGEMAKER_ENDPOINT = os.environ.get('SAGEMAKER_ENDPOINT', 'image-classifier-endpoint')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for image prediction requests.
    
    Args:
        event: API Gateway event containing the request
        context: Lambda context
        
    Returns:
        API Gateway response with prediction results
    """
    try:
        # Parse the request
        if event.get('httpMethod') == 'GET' and event.get('path') == '/health':
            return health_check()
        
        # Handle different endpoints
        path = event.get('path', '')
        
        if path == '/predict':
            return handle_single_prediction(event)
        elif path == '/batch-predict':
            return handle_batch_prediction(event)
        else:
            return create_response(400, {'error': 'Invalid endpoint'})
            
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        return create_response(500, {'error': 'Internal server error'})

def health_check() -> Dict[str, Any]:
    """Health check endpoint."""
    return create_response(200, {
        'status': 'healthy',
        'service': 'AI Image Recognition System',
        'version': '1.0.0'
    })

def handle_single_prediction(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle single image prediction request."""
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        image_data = body.get('image')
        
        if not image_data:
            return create_response(400, {'error': 'No image data provided'})
        
        # Decode base64 image
        image_bytes = base64.b64decode(image_data)
        
        # Perform predictions
        rekognition_results = analyze_with_rekognition(image_bytes)
        custom_model_results = predict_with_custom_model(image_bytes)
        
        # Combine results
        combined_results = {
            'rekognition': rekognition_results,
            'custom_model': custom_model_results,
            'timestamp': context.get_remaining_time_in_millis()
        }
        
        return create_response(200, combined_results)
        
    except Exception as e:
        logger.error(f"Error in single prediction: {str(e)}")
        return create_response(500, {'error': 'Prediction failed'})

def handle_batch_prediction(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle batch image prediction request."""
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        images = body.get('images', [])
        
        if not images:
            return create_response(400, {'error': 'No images provided'})
        
        if len(images) > 10:  # Limit batch size
            return create_response(400, {'error': 'Batch size too large (max 10 images)'})
        
        results = []
        for i, image_data in enumerate(images):
            try:
                image_bytes = base64.b64decode(image_data)
                rekognition_results = analyze_with_rekognition(image_bytes)
                custom_model_results = predict_with_custom_model(image_bytes)
                
                results.append({
                    'image_index': i,
                    'rekognition': rekognition_results,
                    'custom_model': custom_model_results
                })
            except Exception as e:
                logger.error(f"Error processing image {i}: {str(e)}")
                results.append({
                    'image_index': i,
                    'error': 'Failed to process image'
                })
        
        return create_response(200, {'results': results})
        
    except Exception as e:
        logger.error(f"Error in batch prediction: {str(e)}")
        return create_response(500, {'error': 'Batch prediction failed'})

def analyze_with_rekognition(image_bytes: bytes) -> Dict[str, Any]:
    """
    Analyze image using AWS Rekognition.
    
    Args:
        image_bytes: Image data as bytes
        
    Returns:
        Dictionary containing Rekognition analysis results
    """
    try:
        results = {}
        
        # Detect labels
        label_response = rekognition.detect_labels(
            Image={'Bytes': image_bytes},
            MaxLabels=10,
            MinConfidence=70.0
        )
        results['labels'] = [
            {
                'name': label['Name'],
                'confidence': label['Confidence'],
                'instances': len(label.get('Instances', [])),
                'parents': [parent['Name'] for parent in label.get('Parents', [])]
            }
            for label in label_response['Labels']
        ]
        
        # Detect faces
        face_response = rekognition.detect_faces(
            Image={'Bytes': image_bytes},
            Attributes=['ALL']
        )
        results['faces'] = [
            {
                'confidence': face['Confidence'],
                'age_range': face['AgeRange'],
                'gender': face['Gender'],
                'emotions': face['Emotions']
            }
            for face in face_response['FaceDetails']
        ]
        
        # Detect text
        text_response = rekognition.detect_text(
            Image={'Bytes': image_bytes}
        )
        results['text'] = [
            {
                'text': text['DetectedText'],
                'confidence': text['Confidence'],
                'type': text['Type']
            }
            for text in text_response['TextDetections']
        ]
        
        return results
        
    except Exception as e:
        logger.error(f"Error in Rekognition analysis: {str(e)}")
        return {'error': 'Rekognition analysis failed'}

def predict_with_custom_model(image_bytes: bytes) -> Dict[str, Any]:
    """
    Predict using custom SageMaker model.
    
    Args:
        image_bytes: Image data as bytes
        
    Returns:
        Dictionary containing custom model prediction results
    """
    try:
        # Preprocess image for custom model
        processed_image = preprocess_image(image_bytes)
        
        # Convert to JSON format for SageMaker
        payload = json.dumps({
            'instances': [processed_image.tolist()]
        })
        
        # Call SageMaker endpoint
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=SAGEMAKER_ENDPOINT,
            ContentType='application/json',
            Body=payload
        )
        
        # Parse response
        result = json.loads(response['Body'].read().decode())
        
        return {
            'predictions': result.get('predictions', []),
            'model_version': result.get('model_version', 'unknown'),
            'inference_time': result.get('inference_time', 0)
        }
        
    except Exception as e:
        logger.error(f"Error in custom model prediction: {str(e)}")
        return {'error': 'Custom model prediction failed'}

def preprocess_image(image_bytes: bytes) -> np.ndarray:
    """
    Preprocess image for custom model.
    
    Args:
        image_bytes: Image data as bytes
        
    Returns:
        Preprocessed image as numpy array
    """
    try:
        # Load image
        image = Image.open(io.BytesIO(image_bytes))
        
        # Convert to RGB if necessary
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize to model input size (224x224 for most models)
        image = image.resize((224, 224))
        
        # Convert to numpy array and normalize
        image_array = np.array(image) / 255.0
        
        return image_array
        
    except Exception as e:
        logger.error(f"Error preprocessing image: {str(e)}")
        raise

def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create API Gateway response.
    
    Args:
        status_code: HTTP status code
        body: Response body
        
    Returns:
        API Gateway response format
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body, default=str)
    }
