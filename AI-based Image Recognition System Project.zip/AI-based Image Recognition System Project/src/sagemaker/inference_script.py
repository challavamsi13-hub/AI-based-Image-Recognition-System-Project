#!/usr/bin/env python3
"""
SageMaker Inference Script for Image Classification

This script handles model loading and inference for the trained image classifier.
"""

import os
import json
import logging
import torch
import torch.nn as nn
from torchvision import transforms, models
import numpy as np
from PIL import Image
import io
import base64
from typing import Dict, Any, List

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ImageClassifier(nn.Module):
    """Custom image classifier using pre-trained models."""
    
    def __init__(self, num_classes, model_name='resnet50', pretrained=False):
        super(ImageClassifier, self).__init__()
        
        # Load pre-trained model
        if model_name == 'resnet50':
            self.model = models.resnet50(pretrained=pretrained)
            num_features = self.model.fc.in_features
            self.model.fc = nn.Linear(num_features, num_classes)
        elif model_name == 'resnet18':
            self.model = models.resnet18(pretrained=pretrained)
            num_features = self.model.fc.in_features
            self.model.fc = nn.Linear(num_features, num_classes)
        elif model_name == 'efficientnet_b0':
            self.model = models.efficientnet_b0(pretrained=pretrained)
            num_features = self.model.classifier[1].in_features
            self.model.classifier[1] = nn.Linear(num_features, num_classes)
        elif model_name == 'densenet121':
            self.model = models.densenet121(pretrained=pretrained)
            num_features = self.model.classifier.in_features
            self.model.classifier = nn.Linear(num_features, num_classes)
        else:
            raise ValueError(f"Unsupported model: {model_name}")
    
    def forward(self, x):
        return self.model(x)

class ImageClassifierPredictor:
    """Predictor class for image classification."""
    
    def __init__(self, model_dir: str):
        """
        Initialize the predictor.
        
        Args:
            model_dir: Directory containing the model files
        """
        self.model_dir = model_dir
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = None
        self.transform = None
        self.class_names = None
        self.model_info = None
        
        self._load_model()
        self._load_transforms()
    
    def _load_model(self):
        """Load the trained model."""
        try:
            # Load model info
            model_info_path = os.path.join(self.model_dir, 'model_info.json')
            if os.path.exists(model_info_path):
                with open(model_info_path, 'r') as f:
                    self.model_info = json.load(f)
            else:
                # Default model info
                self.model_info = {
                    'model_name': 'resnet50',
                    'num_classes': 10,
                    'input_size': 224
                }
            
            # Create model
            self.model = ImageClassifier(
                num_classes=self.model_info['num_classes'],
                model_name=self.model_info['model_name'],
                pretrained=False
            )
            
            # Load model weights
            model_path = os.path.join(self.model_dir, 'best_model.pth')
            if not os.path.exists(model_path):
                model_path = os.path.join(self.model_dir, 'final_model.pth')
            
            if os.path.exists(model_path):
                self.model.load_state_dict(torch.load(model_path, map_location=self.device))
                logger.info(f"Model loaded from {model_path}")
            else:
                logger.warning("No model weights found, using untrained model")
            
            self.model.to(self.device)
            self.model.eval()
            
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise
    
    def _load_transforms(self):
        """Load data transforms."""
        self.transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    
    def _load_class_names(self):
        """Load class names if available."""
        class_names_path = os.path.join(self.model_dir, 'class_names.json')
        if os.path.exists(class_names_path):
            with open(class_names_path, 'r') as f:
                self.class_names = json.load(f)
        else:
            # Generate default class names
            self.class_names = [f"class_{i}" for i in range(self.model_info['num_classes'])]
    
    def predict(self, image_data: bytes) -> Dict[str, Any]:
        """
        Make prediction on image data.
        
        Args:
            image_data: Image data as bytes
            
        Returns:
            Dictionary containing prediction results
        """
        try:
            # Load class names if not loaded
            if self.class_names is None:
                self._load_class_names()
            
            # Load and preprocess image
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGB if necessary
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Apply transforms
            image_tensor = self.transform(image).unsqueeze(0).to(self.device)
            
            # Make prediction
            with torch.no_grad():
                outputs = self.model(image_tensor)
                probabilities = torch.softmax(outputs, dim=1)
                predicted_class = torch.argmax(probabilities, dim=1).item()
                confidence = probabilities[0][predicted_class].item()
            
            # Get top 5 predictions
            top5_probs, top5_indices = torch.topk(probabilities, 5)
            
            predictions = []
            for i in range(5):
                predictions.append({
                    'class_name': self.class_names[top5_indices[0][i].item()],
                    'class_id': top5_indices[0][i].item(),
                    'confidence': top5_probs[0][i].item()
                })
            
            return {
                'predictions': predictions,
                'top_prediction': {
                    'class_name': self.class_names[predicted_class],
                    'class_id': predicted_class,
                    'confidence': confidence
                },
                'model_info': self.model_info
            }
            
        except Exception as e:
            logger.error(f"Error in prediction: {str(e)}")
            return {'error': 'Prediction failed'}
    
    def predict_batch(self, image_data_list: List[bytes]) -> List[Dict[str, Any]]:
        """
        Make predictions on a batch of images.
        
        Args:
            image_data_list: List of image data as bytes
            
        Returns:
            List of prediction results
        """
        results = []
        for image_data in image_data_list:
            result = self.predict(image_data)
            results.append(result)
        return results

# Global predictor instance
predictor = None

def model_fn(model_dir: str) -> ImageClassifierPredictor:
    """
    Load the model for inference.
    
    Args:
        model_dir: Directory containing the model files
        
    Returns:
        Loaded predictor instance
    """
    global predictor
    predictor = ImageClassifierPredictor(model_dir)
    return predictor

def input_fn(request_body: str, request_content_type: str) -> bytes:
    """
    Parse input data.
    
    Args:
        request_body: Request body as string
        request_content_type: Content type of the request
        
    Returns:
        Parsed input data
    """
    if request_content_type == 'application/json':
        input_data = json.loads(request_body)
        
        if 'image' in input_data:
            # Base64 encoded image
            image_data = base64.b64decode(input_data['image'])
            return image_data
        elif 'images' in input_data:
            # Batch of base64 encoded images
            images = [base64.b64decode(img) for img in input_data['images']]
            return images
        else:
            raise ValueError("No image data found in request")
    
    elif request_content_type == 'application/x-image':
        # Raw image data
        return request_body.encode('utf-8')
    
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data: bytes, model: ImageClassifierPredictor) -> Dict[str, Any]:
    """
    Make prediction.
    
    Args:
        input_data: Input data (image bytes or list of image bytes)
        model: Loaded model
        
    Returns:
        Prediction results
    """
    if isinstance(input_data, list):
        # Batch prediction
        results = model.predict_batch(input_data)
        return {
            'predictions': results,
            'batch_size': len(input_data)
        }
    else:
        # Single prediction
        result = model.predict(input_data)
        return result

def output_fn(prediction: Dict[str, Any], content_type: str) -> str:
    """
    Format output.
    
    Args:
        prediction: Prediction results
        content_type: Expected content type
        
    Returns:
        Formatted output
    """
    if content_type == 'application/json':
        return json.dumps(prediction)
    else:
        raise ValueError(f"Unsupported content type: {content_type}")

# For local testing
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-dir', type=str, required=True)
    parser.add_argument('--image-path', type=str, required=True)
    args = parser.parse_args()
    
    # Load model
    predictor = model_fn(args.model_dir)
    
    # Load image
    with open(args.image_path, 'rb') as f:
        image_data = f.read()
    
    # Make prediction
    result = predict_fn(image_data, predictor)
    
    # Print results
    print(json.dumps(result, indent=2))
