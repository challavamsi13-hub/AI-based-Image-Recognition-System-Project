# Deployment Guide

## Overview

This guide provides step-by-step instructions for deploying the AI Image Recognition System on AWS. The system uses AWS SageMaker, Lambda, API Gateway, and S3 for a complete serverless architecture.

## Prerequisites

### AWS Account Setup

1. **AWS Account**: Ensure you have an active AWS account
2. **AWS CLI**: Install and configure AWS CLI
   ```bash
   pip install awscli
   aws configure
   ```
3. **Terraform**: Install Terraform (version >= 1.0)
   ```bash
   # Download from https://www.terraform.io/downloads.html
   # Or use package manager
   brew install terraform  # macOS
   ```
4. **Docker**: Install Docker for containerization
5. **Python**: Python 3.8 or higher

### Required Permissions

Ensure your AWS user/role has the following permissions:
- AmazonSageMakerFullAccess
- AWSLambdaFullAccess
- AmazonAPIGatewayAdministrator
- AmazonS3FullAccess
- IAMFullAccess
- CloudWatchLogsFullAccess

## Architecture Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Client App    │───▶│  API Gateway    │───▶│   Lambda        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                       │
                                                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   S3 Storage    │◀───│   SageMaker     │◀───│   Rekognition   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Step 1: Environment Setup

### 1.1 Clone the Repository

```bash
git clone <repository-url>
cd ai-image-recognition-system
```

### 1.2 Install Dependencies

```bash
pip install -r requirements.txt
```

### 1.3 Configure Environment Variables

Create a `.env` file in the project root:

```bash
# AWS Configuration
AWS_REGION=us-east-1
AWS_PROFILE=default

# Project Configuration
PROJECT_NAME=ai-image-recognition
ENVIRONMENT=dev

# S3 Configuration
S3_BUCKET_PREFIX=ai-image-recognition-data
MODEL_BUCKET_PREFIX=ai-image-recognition-models

# SageMaker Configuration
SAGEMAKER_ROLE_NAME=ai-image-recognition-sagemaker-role
SAGEMAKER_INSTANCE_TYPE=ml.p3.2xlarge

# Lambda Configuration
LAMBDA_TIMEOUT=30
LAMBDA_MEMORY_SIZE=512
```

## Step 2: Infrastructure Deployment

### 2.1 Initialize Terraform

```bash
cd terraform
terraform init
```

### 2.2 Configure Terraform Variables

Create a `terraform.tfvars` file:

```hcl
aws_region = "us-east-1"
project_name = "ai-image-recognition"
environment = "dev"
lambda_timeout = 30
lambda_memory_size = 512
sagemaker_instance_type = "ml.p3.2xlarge"
sagemaker_instance_count = 1
model_name = "image-classifier"
```

### 2.3 Plan and Apply Infrastructure

```bash
# Review the deployment plan
terraform plan

# Apply the infrastructure
terraform apply
```

### 2.4 Verify Deployment

After successful deployment, note the outputs:

```bash
terraform output
```

Key outputs to save:
- `api_gateway_url`
- `s3_data_bucket`
- `s3_model_bucket`
- `sagemaker_role_arn`

## Step 3: Data Preparation

### 3.1 Prepare Training Data

Organize your dataset in the following structure:

```
data/
├── raw/
│   ├── class1/
│   │   ├── image1.jpg
│   │   ├── image2.jpg
│   │   └── ...
│   ├── class2/
│   │   ├── image1.jpg
│   │   └── ...
│   └── ...
└── processed/
```

### 3.2 Preprocess Data

```bash
python src/utils/data_preprocessing.py \
  --input-dir data/raw \
  --output-dir data/processed \
  --split \
  --augment \
  --input-size 224
```

### 3.3 Upload Data to S3

```bash
# Get the S3 bucket name from Terraform output
S3_BUCKET=$(terraform output -raw s3_data_bucket)

# Upload processed data
aws s3 sync data/processed/ s3://$S3_BUCKET/training-data/
```

## Step 4: Model Training

### 4.1 Create SageMaker Training Job

```bash
# Start training job via API
curl -X POST https://your-api-gateway-url/prod/train \
  -H "Content-Type: application/json" \
  -d '{
    "training_config": {
      "epochs": 10,
      "learning_rate": 0.001,
      "batch_size": 32,
      "model_name": "resnet50",
      "instance_type": "ml.p3.2xlarge"
    }
  }'
```

### 4.2 Monitor Training Progress

```bash
# Check training job status
aws sagemaker describe-training-job \
  --training-job-name <training-job-name>

# View training logs
aws logs tail /aws/sagemaker/TrainingJobs/<training-job-name> \
  --follow
```

### 4.3 Deploy Model

After training completes, deploy the model:

```bash
# Create SageMaker model
aws sagemaker create-model \
  --model-name image-classifier-model \
  --primary-container Image=<training-image>,ModelDataUrl=<model-artifacts-url> \
  --execution-role-arn <sagemaker-role-arn>

# Create endpoint configuration
aws sagemaker create-endpoint-config \
  --endpoint-config-name image-classifier-config \
  --production-variants VariantName=default,ModelName=image-classifier-model,InitialInstanceCount=1,InstanceType=ml.m5.large

# Create endpoint
aws sagemaker create-endpoint \
  --endpoint-name image-classifier-endpoint \
  --endpoint-config-name image-classifier-config
```

## Step 5: Lambda Function Deployment

### 5.1 Package Lambda Functions

```bash
# Create deployment packages
cd src/lambda

# Package predict function
zip -r predict.zip predict.py

# Package train function
zip -r train.zip train.py

cd ../..
```

### 5.2 Update Lambda Functions

```bash
# Update predict function
aws lambda update-function-code \
  --function-name ai-image-recognition-predict \
  --zip-file fileb://src/lambda/predict.zip

# Update train function
aws lambda update-function-code \
  --function-name ai-image-recognition-train \
  --zip-file fileb://src/lambda/train.zip
```

### 5.3 Configure Environment Variables

```bash
# Set environment variables for predict function
aws lambda update-function-configuration \
  --function-name ai-image-recognition-predict \
  --environment Variables='{
    "S3_BUCKET":"'$S3_BUCKET'",
    "MODEL_BUCKET":"'$MODEL_BUCKET'",
    "AWS_REGION":"us-east-1",
    "SAGEMAKER_ENDPOINT":"image-classifier-endpoint"
  }'
```

## Step 6: API Testing

### 6.1 Test Health Endpoint

```bash
curl -X GET https://your-api-gateway-url/prod/health
```

Expected response:
```json
{
  "status": "healthy",
  "service": "AI Image Recognition System",
  "version": "1.0.0"
}
```

### 6.2 Test Single Prediction

```bash
# Encode test image
IMAGE_BASE64=$(base64 -w 0 test_image.jpg)

# Make prediction request
curl -X POST https://your-api-gateway-url/prod/predict \
  -H "Content-Type: application/json" \
  -d '{
    "image": "'$IMAGE_BASE64'"
  }'
```

### 6.3 Test Batch Prediction

```bash
# Encode multiple images
IMAGES=()
for img in test_images/*.jpg; do
  IMAGES+=("$(base64 -w 0 $img)")
done

# Make batch prediction request
curl -X POST https://your-api-gateway-url/prod/batch-predict \
  -H "Content-Type: application/json" \
  -d '{
    "images": ['$(IFS=,; echo "${IMAGES[*]}")']
  }'
```

## Step 7: Monitoring and Logging

### 7.1 Set Up CloudWatch Dashboards

Create a CloudWatch dashboard for monitoring:

```bash
aws cloudwatch put-dashboard \
  --dashboard-name AI-Image-Recognition-Metrics \
  --dashboard-body file://monitoring/dashboard.json
```

### 7.2 Configure Alarms

```bash
# Create API Gateway 4xx error alarm
aws cloudwatch put-metric-alarm \
  --alarm-name API-4xx-Errors \
  --alarm-description "API Gateway 4xx errors" \
  --metric-name 4XXError \
  --namespace AWS/ApiGateway \
  --statistic Sum \
  --period 300 \
  --threshold 10 \
  --comparison-operator GreaterThanThreshold

# Create Lambda error alarm
aws cloudwatch put-metric-alarm \
  --alarm-name Lambda-Errors \
  --alarm-description "Lambda function errors" \
  --metric-name Errors \
  --namespace AWS/Lambda \
  --statistic Sum \
  --period 300 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold
```

### 7.3 Set Up Logging

```bash
# Enable API Gateway logging
aws apigateway update-stage \
  --rest-api-id <api-id> \
  --stage-name prod \
  --patch-operations \
    op=replace,path=/accessLogSettings/destinationArn,value=<log-group-arn> \
    op=replace,path=/accessLogSettings/format,value='$context.identity.sourceIp $context.identity.userAgent $context.authorizer.error $context.error.message $context.integrationError $context.responseLatency $context.status $context.requestId'
```

## Step 8: Security Configuration

### 8.1 Enable API Authentication

```bash
# Create API key
aws apigateway create-api-key \
  --name ai-image-recognition-key \
  --description "API key for image recognition service" \
  --enabled

# Create usage plan
aws apigateway create-usage-plan \
  --name ai-image-recognition-plan \
  --description "Usage plan for image recognition API" \
  --api-stages apiId=<api-id>,stage=prod \
  --quota limit=1000,period=DAY \
  --throttle burstLimit=100,rateLimit=50
```

### 8.2 Configure CORS

Update API Gateway CORS settings:

```bash
aws apigateway update-resource \
  --rest-api-id <api-id> \
  --resource-id <resource-id> \
  --patch-operations \
    op=add,path=/cors,value='{
      "allowOrigins": ["*"],
      "allowHeaders": ["Content-Type", "Authorization"],
      "allowMethods": ["GET", "POST", "OPTIONS"],
      "maxAge": "3600"
    }'
```

## Step 9: Performance Optimization

### 9.1 Lambda Optimization

```bash
# Enable provisioned concurrency
aws lambda put-provisioned-concurrency-config \
  --function-name ai-image-recognition-predict \
  --qualifier prod \
  --provisioned-concurrent-executions 10
```

### 9.2 SageMaker Optimization

```bash
# Configure auto-scaling for endpoint
aws application-autoscaling register-scalable-target \
  --service-namespace sagemaker \
  --scalable-dimension sagemaker:variant:DesiredInstanceCount \
  --resource-id endpoint/image-classifier-endpoint/variant/default \
  --min-capacity 1 \
  --max-capacity 10
```

## Step 10: Backup and Recovery

### 10.1 S3 Lifecycle Policies

```bash
# Create lifecycle policy for data bucket
aws s3api put-bucket-lifecycle-configuration \
  --bucket $S3_BUCKET \
  --lifecycle-configuration file://backup/lifecycle-policy.json
```

### 10.2 Cross-Region Replication

```bash
# Enable cross-region replication
aws s3api put-bucket-replication \
  --bucket $S3_BUCKET \
  --replication-configuration file://backup/replication-config.json
```

## Troubleshooting

### Common Issues

1. **Lambda Timeout Errors**
   - Increase timeout in Terraform configuration
   - Optimize Lambda function code
   - Use provisioned concurrency

2. **SageMaker Training Failures**
   - Check IAM permissions
   - Verify data format in S3
   - Review CloudWatch logs

3. **API Gateway Errors**
   - Check Lambda function logs
   - Verify API Gateway integration
   - Test endpoint directly

4. **S3 Access Issues**
   - Verify bucket policies
   - Check IAM role permissions
   - Ensure bucket exists

### Debug Commands

```bash
# Check Lambda logs
aws logs tail /aws/lambda/ai-image-recognition-predict --follow

# Check SageMaker logs
aws logs tail /aws/sagemaker/TrainingJobs/<job-name> --follow

# Test API Gateway
aws apigateway test-invoke-method \
  --rest-api-id <api-id> \
  --resource-id <resource-id> \
  --http-method POST \
  --path-with-query-string /predict \
  --body '{"image":"test"}'
```

## Cost Optimization

### 1. Lambda Optimization
- Use provisioned concurrency for consistent workloads
- Optimize function code for faster execution
- Set appropriate memory allocation

### 2. SageMaker Optimization
- Use spot instances for training when possible
- Choose appropriate instance types
- Implement auto-scaling for endpoints

### 3. S3 Optimization
- Use S3 Intelligent Tiering
- Implement lifecycle policies
- Compress data when possible

### 4. Monitoring Costs
```bash
# Set up billing alerts
aws budgets create-budget \
  --account-id <account-id> \
  --budget file://monitoring/budget.json \
  --notifications-with-subscribers file://monitoring/notifications.json
```

## Maintenance

### Regular Tasks

1. **Weekly**
   - Review CloudWatch metrics
   - Check for failed training jobs
   - Monitor API usage

2. **Monthly**
   - Update dependencies
   - Review and optimize costs
   - Backup important data

3. **Quarterly**
   - Security audit
   - Performance review
   - Update documentation

### Updates and Upgrades

```bash
# Update Lambda functions
aws lambda update-function-code --function-name <function-name> --zip-file fileb://new-code.zip

# Update SageMaker endpoint
aws sagemaker update-endpoint --endpoint-name <endpoint-name> --endpoint-config-name <new-config-name>
```

## Support and Resources

- **AWS Documentation**: [SageMaker](https://docs.aws.amazon.com/sagemaker/), [Lambda](https://docs.aws.amazon.com/lambda/), [API Gateway](https://docs.aws.amazon.com/apigateway/)
- **Terraform Documentation**: [AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
- **Project Issues**: Create issues in the project repository
- **Community Support**: AWS Developer Forums, Stack Overflow
