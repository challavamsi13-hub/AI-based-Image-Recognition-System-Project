# API Documentation

## Overview

The AI Image Recognition System provides a RESTful API for image analysis using AWS Rekognition and custom SageMaker models. The API supports single image predictions, batch processing, and model training.

## Base URL

```
https://{api-gateway-id}.execute-api.{region}.amazonaws.com/prod
```

## Authentication

Currently, the API does not require authentication. In production, consider implementing API keys or AWS IAM authentication.

## Endpoints

### 1. Health Check

**GET** `/health`

Check the health status of the API.

#### Response

```json
{
  "status": "healthy",
  "service": "AI Image Recognition System",
  "version": "1.0.0"
}
```

#### Example

```bash
curl -X GET https://your-api-gateway-url/prod/health
```

### 2. Single Image Prediction

**POST** `/predict`

Analyze a single image using both AWS Rekognition and custom SageMaker models.

#### Request Body

```json
{
  "image": "base64_encoded_image_data"
}
```

#### Parameters

- `image` (string, required): Base64 encoded image data

#### Response

```json
{
  "rekognition": {
    "labels": [
      {
        "name": "Person",
        "confidence": 95.5,
        "instances": 1,
        "parents": ["People"]
      }
    ],
    "faces": [
      {
        "confidence": 99.5,
        "age_range": {
          "low": 25,
          "high": 35
        },
        "gender": {
          "value": "Male",
          "confidence": 98.0
        },
        "emotions": [
          {
            "type": "Happy",
            "confidence": 85.0
          }
        ]
      }
    ],
    "text": [
      {
        "text": "Hello World",
        "confidence": 95.0,
        "type": "LINE"
      }
    ]
  },
  "custom_model": {
    "predictions": [
      {
        "class_name": "cat",
        "class_id": 0,
        "confidence": 0.85
      }
    ],
    "model_version": "v1.0",
    "inference_time": 150
  },
  "timestamp": 1640995200000
}
```

#### Example

```bash
curl -X POST https://your-api-gateway-url/prod/predict \
  -H "Content-Type: application/json" \
  -d '{
    "image": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
  }'
```

### 3. Batch Image Prediction

**POST** `/batch-predict`

Analyze multiple images in a single request.

#### Request Body

```json
{
  "images": [
    "base64_encoded_image_1",
    "base64_encoded_image_2",
    "base64_encoded_image_3"
  ]
}
```

#### Parameters

- `images` (array, required): Array of base64 encoded image data
- Maximum 10 images per request

#### Response

```json
{
  "results": [
    {
      "image_index": 0,
      "rekognition": {
        "labels": [...],
        "faces": [...],
        "text": [...]
      },
      "custom_model": {
        "predictions": [...],
        "model_version": "v1.0",
        "inference_time": 150
      }
    },
    {
      "image_index": 1,
      "rekognition": {...},
      "custom_model": {...}
    }
  ]
}
```

#### Example

```bash
curl -X POST https://your-api-gateway-url/prod/batch-predict \
  -H "Content-Type: application/json" \
  -d '{
    "images": [
      "base64_image_1",
      "base64_image_2"
    ]
  }'
```

### 4. Model Training

**POST** `/train`

Start a new SageMaker training job for the custom model.

#### Request Body

```json
{
  "training_config": {
    "epochs": 10,
    "learning_rate": 0.001,
    "batch_size": 32,
    "model_name": "resnet50",
    "instance_type": "ml.p3.2xlarge",
    "instance_count": 1
  }
}
```

#### Parameters

- `training_config` (object, optional): Training configuration
  - `epochs` (integer): Number of training epochs (default: 10)
  - `learning_rate` (float): Learning rate (default: 0.001)
  - `batch_size` (integer): Batch size (default: 32)
  - `model_name` (string): Model architecture (default: "resnet50")
  - `instance_type` (string): SageMaker instance type (default: "ml.p3.2xlarge")
  - `instance_count` (integer): Number of instances (default: 1)

#### Response

```json
{
  "message": "Training job started successfully",
  "training_job_name": "image-classifier-20231201-120000-abc12345",
  "status": "InProgress",
  "timestamp": "2023-12-01T12:00:00Z"
}
```

#### Example

```bash
curl -X POST https://your-api-gateway-url/prod/train \
  -H "Content-Type: application/json" \
  -d '{
    "training_config": {
      "epochs": 15,
      "learning_rate": 0.0005,
      "model_name": "efficientnet_b0"
    }
  }'
```

## Error Responses

### 400 Bad Request

```json
{
  "error": "No image data provided"
}
```

### 500 Internal Server Error

```json
{
  "error": "Internal server error"
}
```

## Rate Limits

- Single prediction: 1000 requests per minute
- Batch prediction: 100 requests per minute
- Training: 10 requests per minute

## Supported Image Formats

- JPEG (.jpg, .jpeg)
- PNG (.png)
- BMP (.bmp)
- TIFF (.tiff)

## Image Size Limits

- Maximum image size: 5MB
- Recommended resolution: 224x224 pixels
- Images are automatically resized to 224x224 for custom model inference

## AWS Rekognition Features

The API uses AWS Rekognition for the following analyses:

### Label Detection
- Identifies objects, scenes, and activities in images
- Returns confidence scores and hierarchical labels
- Maximum 10 labels per image

### Face Detection
- Detects faces and facial features
- Provides age range, gender, and emotion analysis
- Returns confidence scores for each attribute

### Text Detection
- Extracts text from images (OCR)
- Supports multiple languages
- Returns text content and confidence scores

## Custom Model Features

The custom SageMaker model provides:

- Multi-class image classification
- Support for various architectures (ResNet, EfficientNet, DenseNet)
- Top-5 predictions with confidence scores
- Model version tracking

## SDK Examples

### Python

```python
import requests
import base64

# Single prediction
with open('image.jpg', 'rb') as f:
    image_data = base64.b64encode(f.read()).decode('utf-8')

response = requests.post('https://your-api-gateway-url/prod/predict', 
                        json={'image': image_data})
result = response.json()
print(f"Predicted class: {result['custom_model']['predictions'][0]['class_name']}")

# Batch prediction
images = []
for image_path in ['image1.jpg', 'image2.jpg']:
    with open(image_path, 'rb') as f:
        image_data = base64.b64encode(f.read()).decode('utf-8')
        images.append(image_data)

response = requests.post('https://your-api-gateway-url/prod/batch-predict',
                        json={'images': images})
results = response.json()
```

### JavaScript

```javascript
// Single prediction
const fs = require('fs');

const imageBuffer = fs.readFileSync('image.jpg');
const imageData = imageBuffer.toString('base64');

fetch('https://your-api-gateway-url/prod/predict', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    image: imageData
  })
})
.then(response => response.json())
.then(result => {
  console.log('Prediction:', result.custom_model.predictions[0]);
});
```

### cURL

```bash
# Single prediction
curl -X POST https://your-api-gateway-url/prod/predict \
  -H "Content-Type: application/json" \
  -d @request.json

# Where request.json contains:
{
  "image": "base64_encoded_image_data"
}
```

## Monitoring and Logging

The API provides comprehensive logging for:

- Request/response details
- Processing times
- Error messages
- AWS service interactions

Logs are available in CloudWatch Logs.

## Cost Optimization

To optimize costs:

1. Use batch predictions for multiple images
2. Choose appropriate SageMaker instance types for training
3. Monitor API usage and set up billing alerts
4. Consider using AWS Lambda provisioned concurrency for consistent performance

## Security Best Practices

1. Implement API authentication (API keys, IAM)
2. Use HTTPS for all requests
3. Validate input data
4. Set up proper IAM roles and permissions
5. Enable CloudTrail for audit logging
6. Regularly update dependencies

## Support

For technical support:

1. Check the logs in CloudWatch
2. Review the error messages in API responses
3. Contact the development team
4. Create an issue in the project repository
