#!/usr/bin/env python3
"""
Deployment script for AI Image Recognition System

This script automates the deployment of the AI image recognition system
including infrastructure, Lambda functions, and API Gateway.
"""

import os
import sys
import json
import subprocess
import boto3
import time
import zipfile
import logging
from pathlib import Path
from typing import Dict, Any, Optional
import argparse

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AIImageRecognitionDeployer:
    """Deployment class for AI Image Recognition System."""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the deployer.
        
        Args:
            config: Deployment configuration
        """
        self.config = config
        self.region = config.get('aws_region', 'us-east-1')
        self.project_name = config.get('project_name', 'ai-image-recognition')
        
        # Initialize AWS clients
        self.s3 = boto3.client('s3', region_name=self.region)
        self.lambda_client = boto3.client('lambda', region_name=self.region)
        self.sagemaker = boto3.client('sagemaker', region_name=self.region)
        self.apigateway = boto3.client('apigateway', region_name=self.region)
        
        # Get outputs from Terraform
        self.outputs = self._get_terraform_outputs()
    
    def _get_terraform_outputs(self) -> Dict[str, Any]:
        """Get Terraform outputs."""
        try:
            result = subprocess.run(
                ['terraform', 'output', '-json'],
                cwd='terraform',
                capture_output=True,
                text=True,
                check=True
            )
            return json.loads(result.stdout)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get Terraform outputs: {e}")
            return {}
    
    def deploy_infrastructure(self) -> bool:
        """Deploy AWS infrastructure using Terraform."""
        try:
            logger.info("Deploying infrastructure with Terraform...")
            
            # Initialize Terraform
            subprocess.run(['terraform', 'init'], cwd='terraform', check=True)
            
            # Plan deployment
            subprocess.run(['terraform', 'plan'], cwd='terraform', check=True)
            
            # Apply deployment
            subprocess.run(['terraform', 'apply', '-auto-approve'], cwd='terraform', check=True)
            
            logger.info("Infrastructure deployment completed successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Infrastructure deployment failed: {e}")
            return False
    
    def package_lambda_functions(self) -> bool:
        """Package Lambda functions for deployment."""
        try:
            logger.info("Packaging Lambda functions...")
            
            lambda_dir = Path('src/lambda')
            
            # Package predict function
            predict_zip = lambda_dir / 'predict.zip'
            with zipfile.ZipFile(predict_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(lambda_dir / 'predict.py', 'predict.py')
            
            # Package train function
            train_zip = lambda_dir / 'train.zip'
            with zipfile.ZipFile(train_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(lambda_dir / 'train.py', 'train.py')
            
            logger.info("Lambda functions packaged successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to package Lambda functions: {e}")
            return False
    
    def deploy_lambda_functions(self) -> bool:
        """Deploy Lambda functions to AWS."""
        try:
            logger.info("Deploying Lambda functions...")
            
            lambda_dir = Path('src/lambda')
            
            # Deploy predict function
            predict_function_name = f"{self.project_name}-predict"
            predict_zip_path = lambda_dir / 'predict.zip'
            
            with open(predict_zip_path, 'rb') as f:
                self.lambda_client.update_function_code(
                    FunctionName=predict_function_name,
                    ZipFile=f.read()
                )
            
            # Update environment variables for predict function
            self.lambda_client.update_function_configuration(
                FunctionName=predict_function_name,
                Environment={
                    'Variables': {
                        'S3_BUCKET': self.outputs.get('s3_data_bucket', {}).get('value', ''),
                        'MODEL_BUCKET': self.outputs.get('s3_model_bucket', {}).get('value', ''),
                        'AWS_REGION': self.region,
                        'SAGEMAKER_ENDPOINT': 'image-classifier-endpoint'
                    }
                }
            )
            
            # Deploy train function
            train_function_name = f"{self.project_name}-train"
            train_zip_path = lambda_dir / 'train.zip'
            
            with open(train_zip_path, 'rb') as f:
                self.lambda_client.update_function_code(
                    FunctionName=train_function_name,
                    ZipFile=f.read()
                )
            
            # Update environment variables for train function
            self.lambda_client.update_function_configuration(
                FunctionName=train_function_name,
                Environment={
                    'Variables': {
                        'S3_BUCKET': self.outputs.get('s3_data_bucket', {}).get('value', ''),
                        'MODEL_BUCKET': self.outputs.get('s3_model_bucket', {}).get('value', ''),
                        'AWS_REGION': self.region,
                        'SAGEMAKER_ROLE_ARN': self.outputs.get('sagemaker_role_arn', {}).get('value', '')
                    }
                }
            )
            
            logger.info("Lambda functions deployed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to deploy Lambda functions: {e}")
            return False
    
    def deploy_sagemaker_model(self, model_path: str, model_name: str = 'image-classifier') -> bool:
        """Deploy SageMaker model."""
        try:
            logger.info(f"Deploying SageMaker model: {model_name}")
            
            # Create model
            model_arn = self.sagemaker.create_model(
                ModelName=model_name,
                PrimaryContainer={
                    'Image': '763104351884.dkr.ecr.us-east-1.amazonaws.com/pytorch-inference:1.13.1-cpu-py39-ubuntu20.04-ec2',
                    'ModelDataUrl': model_path,
                    'Environment': {
                        'SAGEMAKER_PROGRAM': 'inference_script.py',
                        'SAGEMAKER_SUBMIT_DIRECTORY': '/opt/ml/code',
                        'SAGEMAKER_CONTAINER_LOG_LEVEL': '20'
                    }
                },
                ExecutionRoleArn=self.outputs.get('sagemaker_role_arn', {}).get('value', '')
            )['ModelArn']
            
            # Create endpoint configuration
            endpoint_config_name = f"{model_name}-config"
            self.sagemaker.create_endpoint_config(
                EndpointConfigName=endpoint_config_name,
                ProductionVariants=[
                    {
                        'VariantName': 'default',
                        'ModelName': model_name,
                        'InitialInstanceCount': 1,
                        'InstanceType': 'ml.m5.large'
                    }
                ]
            )
            
            # Create endpoint
            endpoint_name = f"{model_name}-endpoint"
            self.sagemaker.create_endpoint(
                EndpointName=endpoint_name,
                EndpointConfigName=endpoint_config_name
            )
            
            # Wait for endpoint to be in service
            logger.info("Waiting for endpoint to be in service...")
            waiter = self.sagemaker.get_waiter('endpoint_in_service')
            waiter.wait(EndpointName=endpoint_name)
            
            logger.info(f"SageMaker model deployed successfully: {endpoint_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to deploy SageMaker model: {e}")
            return False
    
    def test_api_endpoints(self) -> bool:
        """Test API endpoints."""
        try:
            logger.info("Testing API endpoints...")
            
            api_url = self.outputs.get('api_gateway_url', {}).get('value', '')
            if not api_url:
                logger.error("API Gateway URL not found in Terraform outputs")
                return False
            
            # Test health endpoint
            import requests
            
            health_url = f"{api_url}/health"
            response = requests.get(health_url)
            
            if response.status_code == 200:
                logger.info("Health endpoint test passed")
            else:
                logger.error(f"Health endpoint test failed: {response.status_code}")
                return False
            
            # Test predict endpoint with sample data
            predict_url = f"{api_url}/predict"
            
            # Create a simple test image (1x1 pixel)
            import base64
            test_image_data = base64.b64encode(b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x07tIME\x07\xe5\x0c\x1d\x0e\x1c\x0c\xc8\xc8\xc8\x00\x00\x00\x0cIDATx\x9cc```\x00\x00\x00\x04\x00\x01\xf5\xc7\xdd\x8c\x00\x00\x00\x00IEND\xaeB`\x82').decode('utf-8')
            
            response = requests.post(
                predict_url,
                json={'image': test_image_data},
                timeout=30
            )
            
            if response.status_code in [200, 500]:  # 500 is expected if SageMaker endpoint is not ready
                logger.info("Predict endpoint test completed")
            else:
                logger.error(f"Predict endpoint test failed: {response.status_code}")
                return False
            
            logger.info("API endpoint tests completed")
            return True
            
        except Exception as e:
            logger.error(f"Failed to test API endpoints: {e}")
            return False
    
    def upload_sample_data(self, data_dir: str) -> bool:
        """Upload sample data to S3."""
        try:
            logger.info("Uploading sample data to S3...")
            
            s3_bucket = self.outputs.get('s3_data_bucket', {}).get('value', '')
            if not s3_bucket:
                logger.error("S3 bucket not found in Terraform outputs")
                return False
            
            # Upload data directory
            subprocess.run([
                'aws', 's3', 'sync', data_dir, f's3://{s3_bucket}/training-data/',
                '--region', self.region
            ], check=True)
            
            logger.info("Sample data uploaded successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to upload sample data: {e}")
            return False
    
    def create_monitoring_dashboard(self) -> bool:
        """Create CloudWatch monitoring dashboard."""
        try:
            logger.info("Creating CloudWatch monitoring dashboard...")
            
            dashboard_body = {
                "widgets": [
                    {
                        "type": "metric",
                        "x": 0,
                        "y": 0,
                        "width": 12,
                        "height": 6,
                        "properties": {
                            "metrics": [
                                ["AWS/ApiGateway", "Count", "ApiName", f"{self.project_name}-api"],
                                [".", "4XXError", ".", "."],
                                [".", "5XXError", ".", "."]
                            ],
                            "view": "timeSeries",
                            "stacked": False,
                            "region": self.region,
                            "title": "API Gateway Metrics"
                        }
                    },
                    {
                        "type": "metric",
                        "x": 12,
                        "y": 0,
                        "width": 12,
                        "height": 6,
                        "properties": {
                            "metrics": [
                                ["AWS/Lambda", "Invocations", "FunctionName", f"{self.project_name}-predict"],
                                [".", "Errors", ".", "."],
                                [".", "Duration", ".", "."]
                            ],
                            "view": "timeSeries",
                            "stacked": False,
                            "region": self.region,
                            "title": "Lambda Function Metrics"
                        }
                    }
                ]
            }
            
            import boto3
            cloudwatch = boto3.client('cloudwatch', region_name=self.region)
            
            cloudwatch.put_dashboard(
                DashboardName=f"{self.project_name}-dashboard",
                DashboardBody=json.dumps(dashboard_body)
            )
            
            logger.info("CloudWatch dashboard created successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create monitoring dashboard: {e}")
            return False
    
    def deploy(self, options: Dict[str, Any]) -> bool:
        """
        Deploy the complete system.
        
        Args:
            options: Deployment options
            
        Returns:
            True if deployment successful, False otherwise
        """
        try:
            logger.info("Starting AI Image Recognition System deployment...")
            
            # Step 1: Deploy infrastructure
            if options.get('deploy_infrastructure', True):
                if not self.deploy_infrastructure():
                    return False
            
            # Step 2: Package Lambda functions
            if not self.package_lambda_functions():
                return False
            
            # Step 3: Deploy Lambda functions
            if not self.deploy_lambda_functions():
                return False
            
            # Step 4: Deploy SageMaker model (if model path provided)
            if options.get('model_path'):
                if not self.deploy_sagemaker_model(options['model_path']):
                    return False
            
            # Step 5: Upload sample data (if data directory provided)
            if options.get('data_dir'):
                if not self.upload_sample_data(options['data_dir']):
                    return False
            
            # Step 6: Create monitoring dashboard
            if options.get('create_dashboard', True):
                if not self.create_monitoring_dashboard():
                    logger.warning("Failed to create monitoring dashboard")
            
            # Step 7: Test API endpoints
            if options.get('test_api', True):
                if not self.test_api_endpoints():
                    logger.warning("API endpoint tests failed")
            
            logger.info("Deployment completed successfully!")
            
            # Print deployment summary
            self._print_deployment_summary()
            
            return True
            
        except Exception as e:
            logger.error(f"Deployment failed: {e}")
            return False
    
    def _print_deployment_summary(self):
        """Print deployment summary."""
        print("\n" + "="*60)
        print("DEPLOYMENT SUMMARY")
        print("="*60)
        
        if self.outputs:
            print(f"API Gateway URL: {self.outputs.get('api_gateway_url', {}).get('value', 'N/A')}")
            print(f"S3 Data Bucket: {self.outputs.get('s3_data_bucket', {}).get('value', 'N/A')}")
            print(f"S3 Model Bucket: {self.outputs.get('s3_model_bucket', {}).get('value', 'N/A')}")
            print(f"Lambda Predict Function: {self.outputs.get('lambda_predict_function', {}).get('value', 'N/A')}")
            print(f"Lambda Train Function: {self.outputs.get('lambda_train_function', {}).get('value', 'N/A')}")
        
        print("\nAPI Endpoints:")
        endpoints = self.outputs.get('api_endpoints', {}).get('value', {})
        for name, url in endpoints.items():
            print(f"  {name}: {url}")
        
        print("\nNext Steps:")
        print("1. Upload your training data to the S3 bucket")
        print("2. Start a training job using the /train endpoint")
        print("3. Deploy the trained model to SageMaker")
        print("4. Test predictions using the /predict endpoint")
        print("5. Monitor the system using CloudWatch")
        
        print("="*60)

def load_config(config_path: str) -> Dict[str, Any]:
    """Load deployment configuration."""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.warning(f"Config file {config_path} not found, using defaults")
        return {}
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in config file: {e}")
        return {}

def main():
    """Main deployment function."""
    parser = argparse.ArgumentParser(description='Deploy AI Image Recognition System')
    parser.add_argument('--config', type=str, default='deployment_config.json',
                       help='Path to deployment configuration file')
    parser.add_argument('--model-path', type=str, help='Path to trained model artifacts')
    parser.add_argument('--data-dir', type=str, help='Path to training data directory')
    parser.add_argument('--skip-infrastructure', action='store_true',
                       help='Skip infrastructure deployment')
    parser.add_argument('--skip-dashboard', action='store_true',
                       help='Skip CloudWatch dashboard creation')
    parser.add_argument('--skip-api-test', action='store_true',
                       help='Skip API endpoint testing')
    
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Merge command line arguments with config
    options = {
        'deploy_infrastructure': not args.skip_infrastructure,
        'create_dashboard': not args.skip_dashboard,
        'test_api': not args.skip_api_test,
        'model_path': args.model_path,
        'data_dir': args.data_dir
    }
    
    # Create deployer
    deployer = AIImageRecognitionDeployer(config)
    
    # Run deployment
    success = deployer.deploy(options)
    
    if success:
        logger.info("Deployment completed successfully!")
        sys.exit(0)
    else:
        logger.error("Deployment failed!")
        sys.exit(1)

if __name__ == '__main__':
    main()
